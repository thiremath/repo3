package studentCoursesMgmt.util;

public interface FileDisplayInterface {
	
}
