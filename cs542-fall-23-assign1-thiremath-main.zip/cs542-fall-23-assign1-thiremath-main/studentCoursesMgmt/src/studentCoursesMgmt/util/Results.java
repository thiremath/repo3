package studentCoursesMgmt.util;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {
	
}
