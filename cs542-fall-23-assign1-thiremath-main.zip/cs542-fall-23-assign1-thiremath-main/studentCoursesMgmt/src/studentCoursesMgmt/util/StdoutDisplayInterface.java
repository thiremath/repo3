package studentCoursesMgmt.util;

public interface StdoutDisplayInterface {
	
}
